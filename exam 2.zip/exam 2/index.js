const express = require('express');
const axios = require('axios');
const app = express();
const PORT = 3000;

app.set('view engine', 'ejs');
app.use(express.static('public')); // To serve static files like CSS

// Route to display the main page with the button
app.get('/', (req, res) => {
    res.render('index', { countries: null });
});

// Route to get the specific countries and return them to the front-end
app.get('/countries', async (req, res) => {
    try {
        // Fetch data for China (CN), Russia (RU), and Mali (ML)
        const urls = [
            'https://restcountries.com/v3.1/alpha/cn',
            'https://restcountries.com/v3.1/alpha/ru',
            'https://restcountries.com/v3.1/alpha/ml'
        ];

        // Making multiple HTTP requests for the given country codes
        const requests = urls.map(url => axios.get(url));
        const responses = await Promise.all(requests);
        const countries = responses.map(response => response.data[0]); // Each response is an array, get the first element

        res.render('index', { countries });
    } catch (error) {
        console.error(error);
        res.status(500).send('An error occurred');
    }
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
